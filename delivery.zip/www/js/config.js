/*Driver App Configuration*/

var krms_driver_config ={			
	'ApiUrl':"http://fmcgbasket.ae/delivery/driver/api",		
	'DialogDefaultTitle':"FMCGDriverApp",
	'mapboxToken' : '',
	'APIHasKey':"HDSBVHB4389HUDC843FGCHIWA2839HCJSD0932",
	'debug': false
};